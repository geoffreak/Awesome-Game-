// JavaScript Document
var Location = function(x, y, subX, subY, pixelX, pixelY){
	var toString = function(addPixels){
		var str = loc.x + 'x,' + loc.y + 'y';
		str += ',' + loc.subX + 'subX,' + loc.subY + 'subY';
		if (addPixels) 
			str += ',' + loc.pixelX + 'pixelX,' + loc.pixelY + 'pixelY';
		return str;
	}
	var equals = function(otherLoc){
		return toString() == otherLoc.toString();
	};
	var directionTo = function(otherLoc){
		var startX = loc.x * SUBCELL_COUNT + loc.subX;
		var startY = loc.y * SUBCELL_COUNT + loc.subY;
		var goalX = otherLoc.x * SUBCELL_COUNT + otherLoc.subX;
		var goalY = otherLoc.y * SUBCELL_COUNT + otherLoc.subY;
		var deltaX = goalX - startX;
		var deltaY = goalY - startY;
		var slope = deltaY / deltaX;
		if (-4 <= slope && slope < -1/4)
		{
			if (deltaY < 0)
				return Direction.NORTHEAST;
			else
				return Direction.SOUTHWEST;
		}
		else if (1/4 <= slope && slope < 4)
		{
			if (deltaY < 0)
				return Direction.NORTHWEST;
			else
				return Direction.SOUTHEAST;
		}
		else if (4 <= slope || slope < -4)
		{
			if (deltaY < 0)
				return Direction.NORTH;
			else
				return Direction.SOUTH;
		}
		else if (-1/4 <= slope && slope < 1/4)
		{
			if (deltaX < 0)
				return Direction.WEST;
			else
				return Direction.EAST;
		}
	}
	var clone = function(){
		return Location(loc.x,loc.y,loc.subX,loc.subY,loc.pixelX,loc.pixelY);
	}
	var loc = {
		x: x, 
		y: y, 
		subX: (typeof subX == 'undefined') ? 0 : subX, 
		subY: (typeof subY == 'undefined') ? 0 : subY,
		pixelX: (typeof pixelX == 'undefined') ? 0 : pixelX,
		pixelY: (typeof pixelX == 'undefined') ? 0 : pixelY,
		toString: toString,
		equals: equals,
		directionTo: directionTo,
		clone: clone
	}
	return loc;
}

var Direction = {
	NORTH: 0,
	NORTHEAST: 1,
	EAST: 2,
	SOUTHEAST: 3,
	SOUTH: 4,
	SOUTHWEST: 5,
	WEST: 6,
	NORTHWEST: 7
};