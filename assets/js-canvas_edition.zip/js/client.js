// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function(from, to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};
$(function(){
	var counter = 0;
	var lastClass = 'player1_e_stand';
	setInterval(function(){
		$('.player').toggleClass(lastClass);
		var direction;
		//console.log(Math.floor(counter / 4) % 4);
		switch (Math.floor(counter / 16) % 4)
		{
			case 0:
				if (counter >= 16) counter = 0;
				direction = 'n';
				break;
			case 1:
				direction = 'e';
				break;
			case 2:
				direction = 's';
				break;
			case 3:
				direction = 'w';
				break;
		}
		switch (counter++ % 4)
		{
			case 0:
			case 2:
				lastClass = 'player1_'+direction+'_stand';
				break;
			case 1:
				lastClass = 'player1_'+direction+'_right';
				break;
			case 3:
				lastClass = 'player1_'+direction+'_left';
				break;
		}
		console.log(counter);
		$('.player').toggleClass(lastClass);
	}, 250) 
	var canvas = $('canvas')[0];
	if (canvas && canvas.getContext)
	{
		window.PLAYER = new Player();
		window.LOOP = new Loop();
		window.GRID = new Grid(canvas.getContext('2d'));
		for (var x = -1; x <= 1; x++)
		{
			for (var y = -1; y <= 1; y++)
			{
				GRID.addCell(new Cell(Location(x, y), 'bg.png'));
			}
		}
		LOOP.addLoopElement(PLAYER);
		LOOP.start();
		$('canvas').click(function(e){
			var x = e.pageX - this.offsetLeft;
			var y = e.pageY - this.offsetTop;
			var newLoc = GRID.getLocation(x, y)
			if (newLoc) 
			{
				var playerLoc = PLAYER.getLocation();
				GRID.pathFind(playerLoc, newLoc, function(path){
					PLAYER.moveTo(path);
				});
				//console.log(newLoc);
				//console.log(GRID.distance(PLAYER.getLocation(), newLoc))
				//PLAYER.setLocation(newLoc);
				//console.log(GRID.getNearby(newLoc));
				//LOOP.redraw();
			}
			//GRID.move(x, y);
		});
		var runonce = false;
		$(window).resize(function(){
			var w = $(window).width();
			var h = $(window).height();
			$('canvas').attr('width', w);
			$('canvas').attr('height', h);
			GRID.resize(w, h);
			if (!runonce) runonce = true;
			else LOOP.redraw();
		}).resize();
	}
	else
	{
		alert('Need canvas support in browser or no canvas present');	
	}
});