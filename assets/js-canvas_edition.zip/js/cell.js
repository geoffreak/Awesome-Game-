// JavaScript Document
var Cell = function(location, img){
	var loc = location, vLoc, image = new Image(), ready = false, loadCallback;
	var contents = {}
	for (var x = 0; x < CELLSIZE / SUBCELL_DIAM; x++)
	{
		contents[x] = {};
		for (var y = 0; y < CELLSIZE / SUBCELL_DIAM; y++)
		{
			//set 1 when occupied, 0 when free
			contents[x][y] = Math.random() <= 0.1;
		}
	}
	image.src = img;
	image.onload = function(){
		ready = true;
		if (loadCallback) loadCallback();
		//console.log(image.src + ' is loaded');
		//context.drawImage(image, x, y);
	};
	var onload = function(cb){
		if (ready)
			cb();
		else
			loadCallback = cb;
	};
	var isReady = function(){
		return ready;
	};
	var getLocation = function(){
		return loc;
	};
	var getVLocation = function(){
		return vLoc;
	};
	var setVLocation = function(location){
		vLoc = location;
	};
	var draw = function(context){
		//context.drawImage(image, loc.x, loc.y, CELLSIZE, CELLSIZE);
		/*for (var x = 0; x < CELLSIZE / SUBCELL_DIAM; x++)
		{
			for (var y = 0; y < CELLSIZE / SUBCELL_DIAM; y++)
			{
				
				if (contents[x][y])
				{
					context.beginPath();
					context.rect(x * SUBCELL_DIAM, y * SUBCELL_DIAM, SUBCELL_DIAM, SUBCELL_DIAM)
					context.closePath();
					context.fillStyle = "black";
					context.strokeStyle = "black";
					context.fill();
					context.stroke();
				}
				/*else 
				{
					context.fillStyle = "white";
					context.strokeStyle = "blue";
				}/
				
			}
		}*/
		context.beginPath();
		context.rect(0, 0, CELLSIZE, CELLSIZE)
		context.closePath();
		context.strokeStyle = "red";
		context.stroke();
		return false;
	};
	var isRestrictedLocation = function(loc){
		return contents[loc.subX][loc.subY];
	};
	return {
		isReady: isReady,
		getLocation: getLocation,
		getVLocation: getVLocation,
		setVLocation: setVLocation,
		onload: onload,
		preDraw: draw,
		isRestrictedLocation: isRestrictedLocation
	}
};