// JavaScript Document
window.CELLSIZE = 500;
window.SUBCELL_COUNT = 20;
window.SUBCELL_DIAM = CELLSIZE / SUBCELL_COUNT;

var Grid = function(c){
	var context = c, cells = {};
	var cWidth = 0, cHeight = 0, xOffset = 0, yOffset = 0;
	var addCell = function(cell){
		var loc = cell.getLocation();
		if (typeof cells[loc.x] == 'undefined')
			cells[loc.x] = {};
		cells[loc.x][loc.y] = cell;
		cell.onload(function(){
			LOOP.redraw();
		});
	};
	var logGrid = function(){
		for (var x in cells)
		{
			for (var y in cells[x])
			{
				console.log('('+x+', '+y+') ' + cells[x][y].isReady());
			}
		}
	};
	var draw = function(){
		// Draw background (preDraw)
		var playerLoc = PLAYER.getDisplayLocation();
		context.clearRect(0, 0, cWidth, cHeight);
		var postDraw = Array();
		for (var x in cells)
		{
			for (var y in cells[x])
			{
				var xLoc = xOffset + (x - playerLoc.x) * CELLSIZE - (playerLoc.pixelX + SUBCELL_DIAM/2);
				xLoc -=  playerLoc.subX * SUBCELL_DIAM;
				var yLoc = yOffset + (y - playerLoc.y) * CELLSIZE - (playerLoc.pixelY + SUBCELL_DIAM/2);
				yLoc -=  playerLoc.subY * SUBCELL_DIAM;
				var vLoc = Location(xLoc, yLoc);
				if (vLoc.x + CELLSIZE >= 0 && vLoc.x < cWidth &&
					vLoc.y + CELLSIZE >= 0 && vLoc.y < cHeight)
				{
					cells[x][y].setVLocation(vLoc);
					context.save();
					context.translate(xLoc, yLoc);
					if (cells[x][y].preDraw(context))
					{ // has post draw
						postDraw.push({
							cell: cells[x][y],
							x: xLoc,
							y: yLoc
						});
					}
					context.restore();
				}
				else cells[x][y].setVLocation(false);
			}
		}
		// Draw environment
		//	--- TODO ---
		// Draw "Me"
		//	--- TODO ---
		//  temp below:
		context.save();
		context.beginPath();
		context.arc(xOffset, yOffset, 5.5, 0, Math.PI * 2, false);
		context.closePath();
		context.strokeStyle = "black";
		context.stroke();
		context.fillStyle = "white";
		context.fill();
		context.restore();
		// Draw foreground (postDraw)
		for (var i = 0; i < postDraw.length; i++)
		{
			context.save();
			context.translate(postDraw(i).x, postDraw(i).y);
			postDraw(i).cell.postDraw(context);
			context.restore();
		}
	};
	var getLocation = function(xClick, yClick){
		//console.log('('+xClick+', '+yClick+')')
		for (var x in cells)
		{
			for (var y in cells[x])
			{
				var c = cells[x][y];
				var vLoc = c.getVLocation();
				if (vLoc && 
					vLoc.x <= xClick && xClick < vLoc.x + CELLSIZE && 
					vLoc.y <= yClick && yClick < vLoc.y + CELLSIZE)
				{
					var subLocX = (xClick - vLoc.x);
					var subLocY = (yClick - vLoc.y);
					var pixelX = (subLocX % SUBCELL_DIAM);
					var pixelY = (subLocY % SUBCELL_DIAM);
					subLocX = (subLocX - pixelX) / SUBCELL_DIAM;
					subLocY = (subLocY - pixelY) / SUBCELL_DIAM;
					//pixelX -= SUBCELL_DIAM/2;
					//pixelY -= SUBCELL_DIAM/2;
					return Location(parseInt(x), parseInt(y), subLocX, subLocY/*, pixelX, pixelY*/);
				}
			}
		}
		return false;
	};
	var resize = function(width, height){
		xOffset = (width - width % 2) / 2;
		yOffset = (height - height % 2) / 2;
		cWidth = width;
		cHeight = height;
	};
	var Astar = function(startLoc, goalLoc, cb){
		//console.log(startLoc +' -> '+ goalLoc)
		//The set of nodes already evaluated.
		var closedset = {};
		// The set of tentative nodes to be evaluated.
		var openset = Array();
		openset.push(startLoc);
		// The map of navigated nodes.
		var came_from = {};
		var g_score = {}, h_score = {}, f_score = {}; 
		// Distance from start along optimal path.
		g_score[startLoc] = 0;
		h_score[startLoc] = distance(startLoc, goalLoc),
		// Estimated total distance from start to goal through y.
		f_score[startLoc] = h_score[startLoc];
		var max_run = isRestrictedLocation(goalLoc) ? 200 : 500;
		var lowest_h_score = openset[0];
		var AstarRecur = function()
		{
			if (openset.length > 0 && max_run > 0)
			{
				max_run--;
				//console.log('loop')
				var x = openset[0];
				var index = 0;
				for (var loc = 1; loc < openset.length; loc++)
				{
					if (f_score[openset[loc]] <= f_score[x])
					{
						x = openset[loc]; 
						index = loc;
					}
				}
				if (h_score[x] < h_score[lowest_h_score])
					lowest_h_score = x;
				//console.log(x);
				// x is the node in openset having the lowest f_score
				//console.log(count);
				//console.log(openset);
				if (x.equals(goalLoc))
				{
					var path = Array();
					//console.log(came_from);
					var current_node = goalLoc;
					path.push(current_node);
					while (typeof came_from[current_node] != 'undefined')
					{
						current_node = came_from[current_node]
						path.push(current_node);
					}
					cb(path);
				}
				else
				{
					openset.remove(index);
					closedset[x] = x;
					var potential_moves = getNearby(x);
					for (move in potential_moves)
					{
						var y = potential_moves[move];
						if (typeof closedset[y] != 'undefined')
							continue;
						var tentative_g_score = g_score[x] + distance(x, y);
						var tentative_is_better = false;
						if (openset.indexOf(y) == -1)
						{
							openset.push(y);
							length++;
							tentative_is_better = true;
						}
						else if (tentative_g_score < g_score[y])
						{
							tentative_is_better = true;
						}
						if (tentative_is_better)
						{
							//console.log('better')
							came_from[y] = x;
							g_score[y] = tentative_g_score;
							h_score[y] = distance(y, goalLoc);
							f_score[y] = g_score[y] + h_score[y];
						}
					}
					//console.log(f_score);
					AstarRecur();
				}
			}
			else
			{
				console.log('timed out ' + max_run);
				//failure
				var path = Array();
				//console.log(came_from);
				var current_node = lowest_h_score;
				path.push(current_node);
				while (typeof came_from[current_node] != 'undefined')
				{
					current_node = came_from[current_node]
					path.push(current_node);
				}
				cb(path);
			}
		}
		AstarRecur();
	};
	var getNearby = function(loc, noDiagnalRestrict, noRestrict){
		var moves = {};
		//North
		if (loc.subY == 0) // go to cell above
		{
			if (typeof cells[loc.x][loc.y - 1] != 'undefined')
			{
				moves.north = Location(loc.x, loc.y - 1, loc.subX, SUBCELL_COUNT - 1);
			}
		}
		else // stay in cell
		{
			moves.north = Location(loc.x, loc.y, loc.subX, loc.subY - 1);
		}
		if (moves.north && !noRestrict && isRestrictedLocation(moves.north))
			delete moves.north;
		//South
		if (loc.subY == SUBCELL_COUNT - 1) // go to cell below
		{
			if (typeof cells[loc.x][loc.y + 1] != 'undefined')
			{
				moves.south = Location(loc.x, loc.y + 1, loc.subX, 0);
			}
		}
		else // stay in cell
		{
			moves.south = Location(loc.x, loc.y, loc.subX, loc.subY + 1);
		}
		if (moves.south && !noRestrict && isRestrictedLocation(moves.south))
			delete moves.south;
		//East
		if (loc.subX == SUBCELL_COUNT - 1) // go to cell right
		{
			if (typeof cells[loc.x + 1] != 'undefined' && 
				typeof cells[loc.x + 1][loc.y] != 'undefined')
			{
				moves.east = Location(loc.x + 1, loc.y, 0, loc.subY);
			}
		}
		else // stay in cell
		{
			moves.east = Location(loc.x, loc.y, loc.subX + 1, loc.subY);
		}
		if (moves.east && !noRestrict && isRestrictedLocation(moves.east))
			delete moves.east;
		//West
		if (loc.subX == 0) // go to cell left
		{
			if (typeof cells[loc.x - 1] != 'undefined' && 
				typeof cells[loc.x - 1][loc.y] != 'undefined')
			{
				moves.west = Location(loc.x - 1, loc.y, SUBCELL_COUNT - 1, loc.subY);
			}
		}
		else // stay in cell
		{
			moves.west = Location(loc.x, loc.y, loc.subX - 1, loc.subY);
		}
		if (moves.west && !noRestrict && isRestrictedLocation(moves.west))
			delete moves.west;
		//NorthEast
		if (noDiagnalRestrict || (moves.north && moves.east))
		{
			//if cell is north and east
			if (loc.subX == SUBCELL_COUNT - 1 && loc.subY == 0)
			{
				if (typeof cells[loc.x][loc.y - 1] != 'undefined' &&
					typeof cells[loc.x + 1] != 'undefined' && 
					typeof cells[loc.x + 1][loc.y] != 'undefined')
				{
					moves.northeast = Location(loc.x + 1, loc.y - 1, 0, SUBCELL_COUNT - 1);
				}
			}
			//else if cell is north
			else if (loc.subY == 0)
			{
				if (typeof cells[loc.x][loc.y - 1] != 'undefined')
				{
					moves.northeast = Location(loc.x, loc.y - 1, loc.subX + 1, SUBCELL_COUNT - 1)
				}
			}
			//else if cell is east
			else if (loc.subX == SUBCELL_COUNT - 1)
			{
				if (typeof cells[loc.x + 1] != 'undefined' && 
					typeof cells[loc.x + 1][loc.y] != 'undefined')
				{
					moves.northeast = Location(loc.x + 1, loc.y, 0, loc.subY - 1); 
				}
			}
			//else same cell
			else
			{
				moves.northeast = Location(loc.x, loc.y, loc.subX + 1, loc.subY - 1);
			}
		}
		if (moves.northeast && !noRestrict && isRestrictedLocation(moves.northeast))
			delete moves.northeast;
		//NorthWest
		if (noDiagnalRestrict || (moves.north && moves.west))
		{
			//if cell is north and west
			if (loc.subX == 0 && loc.subY == 0)
			{
				if (typeof cells[loc.x][loc.y - 1] != 'undefined' &&
					typeof cells[loc.x - 1] != 'undefined' && 
					typeof cells[loc.x - 1][loc.y] != 'undefined')
				{
					moves.northwest = Location(loc.x - 1, loc.y - 1, SUBCELL_COUNT - 1, SUBCELL_COUNT - 1);
				}
			}
			//else if cell is north
			else if (loc.subY == 0)
			{
				if (typeof cells[loc.x][loc.y - 1] != 'undefined')
				{
					moves.northwest = Location(loc.x, loc.y - 1, loc.subX - 1, SUBCELL_COUNT - 1)
				}
			}
			//else if cell is west
			else if (loc.subX == 0)
			{
				if (typeof cells[loc.x - 1] != 'undefined' && 
					typeof cells[loc.x - 1][loc.y] != 'undefined')
				{
					moves.northwest = Location(loc.x - 1, loc.y, SUBCELL_COUNT - 1, loc.subY - 1); 
				}
			}
			//else same cell
			else
			{
				moves.northwest = Location(loc.x, loc.y, loc.subX - 1, loc.subY - 1);
			}
		}
		if (moves.northwest && !noRestrict && isRestrictedLocation(moves.northwest))
			delete moves.northwest;
		//SouthEast
		if (noDiagnalRestrict || (moves.south && moves.east))
		{
			//if cell is south and east
			if (loc.subX == SUBCELL_COUNT - 1 && loc.subY == SUBCELL_COUNT - 1)
			{
				if (typeof cells[loc.x][loc.y + 1] != 'undefined' &&
					typeof cells[loc.x + 1] != 'undefined' && 
					typeof cells[loc.x + 1][loc.y] != 'undefined')
				{
					moves.southeast = Location(loc.x + 1, loc.y + 1, 0, 0);
				}
			}
			//else if cell is south
			else if (loc.subY == SUBCELL_COUNT - 1)
			{
				if (typeof cells[loc.x][loc.y + 1] != 'undefined')
				{
					moves.southeast = Location(loc.x, loc.y + 1, loc.subX + 1, 0);
				}
			}
			//else if cell is east
			else if (loc.subX == SUBCELL_COUNT - 1)
			{
				if (typeof cells[loc.x + 1] != 'undefined' && 
					typeof cells[loc.x + 1][loc.y] != 'undefined')
				{
					moves.southeast = Location(loc.x + 1, loc.y, 0, loc.subY + 1); 
				}
			}
			//else same cell
			else
			{
				moves.southeast = Location(loc.x, loc.y, loc.subX + 1, loc.subY + 1);
			}
		}
		if (moves.southeast && !noRestrict && isRestrictedLocation(moves.southeast))
			delete moves.southeast;
		//SouthWest
		if (noDiagnalRestrict || (moves.south && moves.west))
		{
			//if cell is south and west
			if (loc.subX == 0 && loc.subY == SUBCELL_COUNT - 1)
			{
				if (typeof cells[loc.x][loc.y + 1] != 'undefined' &&
					typeof cells[loc.x - 1] != 'undefined' && 
					typeof cells[loc.x - 1][loc.y] != 'undefined')
				{
					moves.southwest = Location(loc.x - 1, loc.y + 1, 0, SUBCELL_COUNT - 1);
				}
			}
			//else if cell is south
			else if (loc.subY == SUBCELL_COUNT - 1)
			{
				if (typeof cells[loc.x][loc.y + 1] != 'undefined')
				{
					moves.southwest = Location(loc.x, loc.y + 1, loc.subX - 1, 0)
				}
			}
			//else if cell is west
			else if (loc.subX == 0)
			{
				if (typeof cells[loc.x - 1] != 'undefined' && 
					typeof cells[loc.x - 1][loc.y] != 'undefined')
				{
					moves.southwest = Location(loc.x - 1, loc.y, SUBCELL_COUNT - 1, loc.subY + 1); 
				}
			}
			//else same cell
			else
			{
				moves.southwest = Location(loc.x, loc.y, loc.subX - 1, loc.subY + 1);
			}
		}
		if (moves.southwest && !noRestrict && isRestrictedLocation(moves.southwest))
			delete moves.southwest;
		return moves;
	};
	var distance = function(startLoc, goalLoc){
		var startX = startLoc.x * SUBCELL_COUNT + startLoc.subX;
		var startY = startLoc.y * SUBCELL_COUNT + startLoc.subY;
		var goalX = goalLoc.x * SUBCELL_COUNT + goalLoc.subX;
		var goalY = goalLoc.y * SUBCELL_COUNT + goalLoc.subY;
		//console.log(startX +','+ startY +' -> '+ goalX +','+ goalY)
		return Math.sqrt(Math.pow(goalX - startX, 2) + Math.pow(goalY - startY, 2));
	};
	var isRestrictedLocation = function(loc){
		return cells[loc.x][loc.y].isRestrictedLocation(loc);
	};
	return {
		addCell: addCell,
		log: logGrid,
		draw: draw,
		resize: resize,
		getLocation: getLocation,
		pathFind: Astar,
		distance: distance,
		getNearby: getNearby
	};
};